using System;
using System.IO;

namespace XTrace
{
    /// <summary>
    /// Static public API for XTrace sampling.
    /// Use this class to capture trace points in your code.
    /// </summary>
    public static class XTraceSampler
    {
        /// <summary>
        /// Gets the number of trace points in the current session.
        /// </summary>
        public static int TraceCount => XTraceSession.Current.Data.TotalPoints;

        #region Sample Overloads - Basic Types

        /// <summary>
        /// Captures a trace point with an integer value.
        /// </summary>
        /// <param name="value">The value to trace.</param>
        /// <param name="prompt">A description or context for this trace.</param>
        public static TracePoint Sample(int value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a boolean value.
        /// </summary>
        public static TracePoint Sample(bool value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a float value.
        /// </summary>
        public static TracePoint Sample(float value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a double value.
        /// </summary>
        public static TracePoint Sample(double value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a string value.
        /// </summary>
        public static TracePoint Sample(string value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a long value.
        /// </summary>
        public static TracePoint Sample(long value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a byte value.
        /// </summary>
        public static TracePoint Sample(byte value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a short value.
        /// </summary>
        public static TracePoint Sample(short value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a decimal value.
        /// </summary>
        public static TracePoint Sample(decimal value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a char value.
        /// </summary>
        public static TracePoint Sample(char value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a DateTime value.
        /// </summary>
        public static TracePoint Sample(DateTime value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a TimeSpan value.
        /// </summary>
        public static TracePoint Sample(TimeSpan value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a Vector2 value (Unity).
        /// </summary>
        public static TracePoint Sample(UnityEngine.Vector2 value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a Vector3 value (Unity).
        /// </summary>
        public static TracePoint Sample(UnityEngine.Vector3 value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a Vector4 value (Unity).
        /// </summary>
        public static TracePoint Sample(UnityEngine.Vector4 value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a Quaternion value (Unity).
        /// </summary>
        public static TracePoint Sample(UnityEngine.Quaternion value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with a Color value (Unity).
        /// </summary>
        public static TracePoint Sample(UnityEngine.Color value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        /// <summary>
        /// Captures a trace point with any object value.
        /// </summary>
        public static TracePoint Sample(object value, string prompt)
        {
            return XTraceSession.Current.Capture(value, prompt);
        }

        #endregion

        #region Session Management

        /// <summary>
        /// Clears all trace points in the current session.
        /// </summary>
        public static void Clear()
        {
            XTraceSession.Current.Clear();
        }

        /// <summary>
        /// Resets the session, starting a new one.
        /// </summary>
        public static void ResetSession()
        {
            XTraceSession.Reset();
        }

        /// <summary>
        /// Gets the current trace data without ending the session.
        /// </summary>
        public static XTraceData GetCurrentData()
        {
            return XTraceSession.Current.Data;
        }

        #endregion

        #region Export/Import

        /// <summary>
        /// Exports the current session to a .xtrace file.
        /// </summary>
        /// <param name="filePath">The file path to write to.</param>
        /// <param name="description">Optional description for the trace session.</param>
        /// <returns>The completed trace data.</returns>
        public static XTraceData Export(string filePath, string description = null)
        {
            var data = XTraceSession.Current.Complete();
            
            if (!string.IsNullOrEmpty(description))
            {
                data.Description = description;
            }

            XTraceExporter.Export(data, filePath);
            return data;
        }

        /// <summary>
        /// Exports the current session to a .xtrace file without completing it.
        /// </summary>
        /// <param name="filePath">The file path to write to.</param>
        /// <param name="description">Optional description for the trace session.</param>
        public static void ExportSnapshot(string filePath, string description = null)
        {
            var data = XTraceSession.Current.Data;
            
            if (!string.IsNullOrEmpty(description))
            {
                data.Description = description;
            }

            XTraceExporter.Export(data, filePath);
        }

        /// <summary>
        /// Imports a .xtrace file.
        /// </summary>
        /// <param name="filePath">The file path to read from.</param>
        /// <returns>The loaded trace data.</returns>
        public static XTraceData Import(string filePath)
        {
            return XTraceImporter.Import(filePath);
        }

        #endregion
    }
}
