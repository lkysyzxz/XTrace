using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace XTrace
{
    internal class XTraceSession
    {
        private static XTraceSession _current;
        private static readonly object _lock = new object();

        private readonly XTraceData _data;
        private int _nextId;
        private readonly long _startTicks;
        private bool _isComplete;

        public static XTraceSession Current
        {
            get
            {
                lock (_lock)
                {
                    if (_current == null || _current._isComplete)
                    {
                        _current = new XTraceSession();
                    }
                    return _current;
                }
            }
        }

        public XTraceData Data => _data;

        private XTraceSession()
        {
            _data = new XTraceData(Guid.NewGuid().ToString("N"), "XTrace");
            _startTicks = Stopwatch.GetTimestamp();
            _nextId = 1;
            _isComplete = false;
        }

        public TracePoint Capture(object value, string prompt, int skipFrames = 2)
        {
            var timestamp = (long)((Stopwatch.GetTimestamp() - _startTicks) * 10000000.0 / Stopwatch.Frequency);
            
            var point = new TracePoint(
                _nextId++,
                timestamp,
                value?.ToString() ?? "null",
                value?.GetType().Name ?? "null",
                prompt ?? ""
            );

            CaptureCallStack(point, skipFrames);

            _data.AddTracePoint(point);
            return point;
        }

        private void CaptureCallStack(TracePoint point, int skipFrames)
        {
            try
            {
                var stack = new StackTrace(skipFrames, true);
                var frameCount = Math.Min(stack.FrameCount, 32);

                for (int i = 0; i < frameCount; i++)
                {
                    var frame = stack.GetFrame(i);
                    if (frame == null) continue;

                    var method = frame.GetMethod();
                    if (method == null) continue;

                    if (method.DeclaringType?.Namespace?.StartsWith("XTrace") == true)
                        continue;

                    var stackFrame = new StackFrame(
                        method.Name,
                        method.DeclaringType?.Name ?? "Unknown",
                        frame.GetFileName() ?? "",
                        frame.GetFileLineNumber()
                    );

                    point.CallStack.Add(stackFrame);
                }
            }
            catch
            {
            }
        }

        public XTraceData Complete()
        {
            lock (_lock)
            {
                _isComplete = true;
                _data.Complete();
                return _data;
            }
        }

        public static void Reset()
        {
            lock (_lock)
            {
                _current = null;
            }
        }

        public void Clear()
        {
            _data.TracePoints.Clear();
            _data.TotalPoints = 0;
            _nextId = 1;
        }
    }
}
