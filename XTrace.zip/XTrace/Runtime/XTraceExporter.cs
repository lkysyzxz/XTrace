using System;
using System.IO;
using System.IO.Compression;
using System.Text;

namespace XTrace
{
    /// <summary>
    /// Handles exporting XTrace data to compressed .xtrace files.
    /// </summary>
    internal static class XTraceExporter
    {
        /// <summary>
        /// File extension for XTrace files.
        /// </summary>
        public const string FileExtension = ".xtrace";

        /// <summary>
        /// Magic bytes to identify XTrace files.
        /// </summary>
        private static readonly byte[] MagicBytes = Encoding.ASCII.GetBytes("XTRC");

        /// <summary>
        /// Exports XTrace data to a file with compression.
        /// </summary>
        /// <param name="data">The trace data to export.</param>
        /// <param name="filePath">The file path to write to.</param>
        public static void Export(XTraceData data, string filePath)
        {
            if (data == null)
                throw new ArgumentNullException(nameof(data));

            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException(nameof(filePath));

            // Ensure correct extension
            if (!filePath.EndsWith(FileExtension, StringComparison.OrdinalIgnoreCase))
            {
                filePath += FileExtension;
            }

            // Ensure directory exists
            var directory = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            // Serialize to JSON
            var json = SerializeToJson(data);
            var jsonBytes = Encoding.UTF8.GetBytes(json);

            // Compress and write
            using (var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
            {
                // Write magic bytes
                fileStream.Write(MagicBytes, 0, MagicBytes.Length);

                // Write format version
                var versionBytes = BitConverter.GetBytes(XTraceData.FormatVersion);
                fileStream.Write(versionBytes, 0, versionBytes.Length);

                // Write compressed data length (uncompressed) for validation
                var lengthBytes = BitConverter.GetBytes(jsonBytes.Length);
                fileStream.Write(lengthBytes, 0, lengthBytes.Length);

                // Compress and write data
                using (var gzipStream = new GZipStream(fileStream, CompressionLevel.Optimal, leaveOpen: true))
                {
                    gzipStream.Write(jsonBytes, 0, jsonBytes.Length);
                }
            }
        }

        /// <summary>
        /// Serializes XTraceData to JSON string.
        /// </summary>
        private static string SerializeToJson(XTraceData data)
        {
            var sb = new StringBuilder();
            sb.Append('{');
            
            // Header
            sb.Append("\"formatVersion\":").Append(XTraceData.FormatVersion).Append(',');
            sb.Append("\"sessionId\":\"").Append(EscapeString(data.SessionId)).Append("\",");
            sb.Append("\"startTime\":\"").Append(EscapeString(data.StartTime)).Append("\",");
            sb.Append("\"endTime\":\"").Append(EscapeString(data.EndTime ?? "")).Append("\",");
            sb.Append("\"applicationName\":\"").Append(EscapeString(data.ApplicationName ?? "")).Append("\",");
            sb.Append("\"description\":\"").Append(EscapeString(data.Description ?? "")).Append("\",");
            sb.Append("\"totalPoints\":").Append(data.TotalPoints).Append(',');

            // Metadata
            sb.Append("\"metadata\":{");
            if (data.Metadata != null && data.Metadata.Count > 0)
            {
                bool first = true;
                foreach (var kvp in data.Metadata)
                {
                    if (!first) sb.Append(',');
                    sb.Append("\"").Append(EscapeString(kvp.Key)).Append("\":\"").Append(EscapeString(kvp.Value)).Append("\"");
                    first = false;
                }
            }
            sb.Append("},");

            // Trace points
            sb.Append("\"tracePoints\":[");
            if (data.TracePoints != null)
            {
                for (int i = 0; i < data.TracePoints.Count; i++)
                {
                    if (i > 0) sb.Append(',');
                    SerializeTracePoint(sb, data.TracePoints[i]);
                }
            }
            sb.Append(']');

            sb.Append('}');
            return sb.ToString();
        }

        private static void SerializeTracePoint(StringBuilder sb, TracePoint point)
        {
            sb.Append('{');
            sb.Append("\"id\":").Append(point.Id).Append(',');
            sb.Append("\"timestamp\":").Append(point.Timestamp).Append(',');
            sb.Append("\"value\":\"").Append(EscapeString(point.Value ?? "")).Append("\",");
            sb.Append("\"valueType\":\"").Append(EscapeString(point.ValueType ?? "")).Append("\",");
            sb.Append("\"prompt\":\"").Append(EscapeString(point.Prompt ?? "")).Append("\",");

            // Call stack
            sb.Append("\"callStack\":[");
            if (point.CallStack != null)
            {
                for (int i = 0; i < point.CallStack.Count; i++)
                {
                    if (i > 0) sb.Append(',');
                    SerializeStackFrame(sb, point.CallStack[i]);
                }
            }
            sb.Append(']');

            sb.Append('}');
        }

        private static void SerializeStackFrame(StringBuilder sb, StackFrame frame)
        {
            sb.Append('{');
            sb.Append("\"methodName\":\"").Append(EscapeString(frame.MethodName ?? "")).Append("\",");
            sb.Append("\"declaringType\":\"").Append(EscapeString(frame.DeclaringType ?? "")).Append("\",");
            sb.Append("\"fileName\":\"").Append(EscapeString(frame.FileName ?? "")).Append("\",");
            sb.Append("\"lineNumber\":").Append(frame.LineNumber);
            sb.Append('}');
        }

        private static string EscapeString(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            
            var sb = new StringBuilder(s.Length);
            foreach (char c in s)
            {
                switch (c)
                {
                    case '\\': sb.Append("\\\\"); break;
                    case '"': sb.Append("\\\""); break;
                    case '\n': sb.Append("\\n"); break;
                    case '\r': sb.Append("\\r"); break;
                    case '\t': sb.Append("\\t"); break;
                    default: sb.Append(c); break;
                }
            }
            return sb.ToString();
        }
    }
}
